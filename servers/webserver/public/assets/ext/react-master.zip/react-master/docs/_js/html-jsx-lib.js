// Ideally it would be nice to just redirect, but Github Pages is very basic and
// lacks that functionality.
console.warn(
  'html-jsx-lib.js has moved to http://reactjs.github.io/react-magic/' +
  'htmltojsx.min.js. If using React-Magic, you are no longer required to ' +
  'link to this file. Please delete its <script> tag.'
);
