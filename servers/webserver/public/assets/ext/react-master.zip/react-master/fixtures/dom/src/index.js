const React = window.React;
const ReactDOM = window.ReactDOM;
import App from './components/App';

ReactDOM.render(
  <App />,
  document.getElementById('root')
);
