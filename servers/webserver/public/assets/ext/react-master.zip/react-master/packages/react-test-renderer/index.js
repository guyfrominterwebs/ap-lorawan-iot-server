'use strict';

module.exports = require('./cjs/react-test-renderer.development');
