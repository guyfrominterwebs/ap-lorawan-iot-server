# Custom ESLint Rules

This is a dummy npm package that allows us to treat it as an eslint-plugin. It's not actually published, nor are the rules here useful for users of react. If you want to lint your react code, try <https://github.com/yannickcr/eslint-plugin-react>.

**If you modify this rule, you must re-run `npm install ./eslint-rules` for it to take effect.**
