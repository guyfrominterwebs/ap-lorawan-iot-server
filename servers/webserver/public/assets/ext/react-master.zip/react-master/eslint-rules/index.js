'use strict';

module.exports = {
  rules: {
    'warning-and-invariant-args': require('./warning-and-invariant-args'),
    'no-primitive-constructors': require('./no-primitive-constructors'),
  },
};
